class MatchAvenir {
  int id;
  String club1;
  String club2;
  String date;
  String img1;
  String img2;

  MatchAvenir(this.id, this.club1, this.club2, this.date, this.img1, this.img2);
}

List<MatchAvenir> ListMatchAvenir = [


    MatchAvenir(
    1,
      'Etoile du kivu',
       'As Vclub',

 
    '26/08/2023',
     'asset/team/et.png',
     'asset/team/vt.jpg',
   
   
  ),
    MatchAvenir(
    1,
       'As Vclub',
  'Primeiro de Agosto',
 
    '27/08/2023',
     'asset/team/vt.jpg',
    'asset/team/cd.png',
   
  ),
  MatchAvenir(
    1,
    'Al Hilal',
    'As Vclub',
    '01/09/2023',
    'asset/team/al.png',
    'asset/team/vt.jpg',
  ),
  MatchAvenir(
    1,
    'Dc Virunga',
    'As Vclub',
    '06/09/2023',
    'asset/team/vr.webp',
    'asset/team/vt.jpg',
  ),
  MatchAvenir(
    1,
    'As Vclub',
    'Fc Simba',
    '08/10/2023',
    'asset/team/vt.jpg',
    'asset/team/sm.png',
  ),
  MatchAvenir(
    1,
    'As Vclub',
    'Al Hilal',
    '11/11/2023',
    'asset/team/vt.jpg',
    'asset/team/al.png',
  ),
];
