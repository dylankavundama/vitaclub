class MatchJouer {
  int id;
  String club1;
  String club2;
  String score;
  String img1;
  String img2;

  MatchJouer(this.id, this.club1, this.club2, this.score, this.img1, this.img2);
}

List<MatchJouer> ListMatchJouer = [

    MatchJouer(
    1,
    'Wydad Casabla',
    'As Vclub',
    '0-0',
      'asset/team/ca.jpg',
    'asset/team/vt.jpg',
  
  ),

      MatchJouer(
    1,
    'Petro Atlético',
    'As Vclub',
    '0-0',
    'asset/team/pt.jpg',
    'asset/team/vt.jpg',
  ),
  MatchJouer(
    1,
    'Tp Mazembe',
    'As Vclub',
    '0-1',
    'asset/team/tp.jpg',
    'asset/team/vt.jpg',
  ),
  MatchJouer(
    1,
'As Vclub',
    'DCMP',
    '4-3',
    'asset/team/vt.jpg',
    'asset/team/dc.jpg',
  ),
  MatchJouer(
    1,
    'Dc Virunga',
    'Av vclub',
    '3-1',
    'asset/team/vr.webp',
    'asset/team/vt.jpg',
  ),
  MatchJouer(
    1,
    'Av vclub',
    'Al Hilal',
    '3-1',
    'asset/team/vt.jpg',
    'asset/team/al.png',
  ),
  MatchJouer(
    1,
    'Fc Simba',
      'Av vclub',
    '1-1',
    'asset/team/sm.png',
    'asset/team/vt.jpg',
  )
];
