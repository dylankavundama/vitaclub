class Post {
  int id;
  String image;
  String like;
  String date;
  String titre;
  String descri;

  Post(this.id, this.image, this.like, this.date, this.titre, this.descri);
}

List<Post> posts = [

    Post(
    5,
    'asset/un.jpg',
    '9',
    '25/08/2023',
    "Mazembe et Maniema Union de cœur avec le Conor",
    "Le TP Mazembe et l'As Maniema Union sont solidaires de la formule proposée par le Comité de normalisation de la Fédération Congolaise de Football Association (Fecofa). Les deux clubs l'ont fait savoir dans leurs communiqués respectifs rendus publics ces derniers jours. Ces communications arrivent 24 heures après la 2ème réunion de travail avortée entre le Comité de normalisation de la Fédération Congolaise de Football Association (Fecofa) et les dirigeants des clubs, prévue le jeudi 10 août dernier avec les absences des officiels de la Fecofa qui ne sont pas venus. Cette rencontre devait débouché normalement sur l'harmonisation de la formule du championnat entre les parties prenantes. La raison de l'absence des dirigeants de la Fecofa n'a pas été signifiée mais ce qui est certain ces derniers ne sont pas d'accord avec la refonte de la formule qu'ils ont proposé en premier lieu. Pour rappel, les dirigeants des clubs ont sollicité et obtenu du ministère des sports d'avoir une rencontre de clarification avec les dirigeants de la Fecofa qu'ils reprochent d'avoir élaboré une formule sans leur consentement.",
  ),
  Post(
    7,
    'asset/a.jpg',
    '10',
    '27/08/2023',
    "Le TPM réclame l'équité sportive",
    "A quelques jours du démarrage de la L1, des voies discordantes s'élèvent pour redéfinir une nouvelle formule. Le TPM demande à tous de privilégier l'équité sportive. Voici la position du club de Kamalondo. Elle est très dommageable la situation du football congolais. Pour déclencher et faire avancer la machine du football national, il ne faut en rien faire intervenir des mécaniciens qui bricolent.Le TPM prépare le championnat national pour ce 23 août. Le club de Kamalondo est engagé en Ligue des Champions de la CAF, en African Football League, en Ligue 1 et Coupe du Congo. Il tient à une organisation efficiente du championnat national et non aux conciliabules sans intérêt sportif.Mazembe tient au challenge interne (RDC) avec à la base un championnat où les points sont chèrement acquis. Il veut et tient à avoir des sponsors pour notre football. Pour y arriver, il faut respecter les principes élémentaires d'organisation. Au CONOR sa charge d'organe technique (penseur et metteur en scène), le TPM s'alignera derrière ses textes et ses règlements.Il faut éviter au football national une dérive totalitaire qui ne pourrait que s’avérer préjudiciable à tous.",
  ),
  Post(
    7,
    'asset/amk.jpg',
    '10',
    '27/08/2023',
    "Louis AMEKA AUTCHANGA nouveau Corbeau",
    "Un nouvel élément offensif rejoint l’effectif des Corbeaux. Le TPM annonce en tête aujourd’hui la signature de Louis AMEKA AUTCHANGA en provenance de Maghreb de Fès. Le milieu de terrain offensif (capable d'évoluer aussi sur les côtés) et international gabonais s’est engagé avec le club pour deux saisons. Aujourd’hui à 27 ans et fort d’une expérience acquise au CF Munana, au Chamois Niortais en France et au Maroc, Louis AMEKA AUTCHANGA vient renforcer le secteur offensif du TPM à l’aube de cette saison 2023-2024. ",
  ),
  Post(
    1,
    'asset/ab.webp',
    '4',
    '22/08/2023',
    'Le championnat national de la RDC démarre le 24 août prochain. 20 clubs partent à l’assaut du titre. Mais 4 clubs sont réellement favoris pour le sacre final.',
    ' Un nouveau challenge des clubs s’ouvre pour la conquête du titre. Les équipes inscrites vont rivaliser d’ardeur pour atteindre leurs objectifs. Pour la plupart, il s’agit de faire bonne impression ou se maintenir de l’élite. Pendant ce temps, quelques clubs ne jurent que sur le titre. Il s’agit des abonnés au sommet de la Ligue chaque année. Les ultra favoris En RDC, deux clubs rivalisent au palmarès du championnat national. Le TP Mazembe qui compte 19 titres et l’AS Vita Club auréolé de 15 sacres. Avec 34 titres à eux seuls sur les 61 éditions, le TP Mazembe et Vita Club sont sans contestation les meilleurs clubs du pays. Aussi détiennent-ils des palmarès élogieux en compétitions africaines. L’AS Vita Club a réussi un sans-faute lors de la première de la saison écoulée hélas abandonnée. De son côté, le TP Mazembe est champion en titre (2021-2022). C’est ainsi qu’ils sont une nouvelle fois les ultra favoris de cette édition. Ils sont connus un mercato très actif avec plusieurs arrivées de taille et des sommes colossales dépensées pour renforcer leur effectif respectif. ',
  ),
  Post(
    2,
    'asset/abdl.jpg',
    '7',
    '22/08/2023',
    "L'ancien défenseur de Kotoko Ismail Abdul-Ganiyu choisit la voie de la FIFA suite à un différend financier avec le TP Mazembe",
    "Le grief de Ganiyu concerne les frais d'inscription impayés qui lui sont dus par le club congolais depuis son arrivée en février 2023. Ayant rejoint le TP Mazembe en provenance du Koweït d'Al Talaba pour un contrat de deux ans et demi, la situation de Ganiyu a pris une tournure inattendue. La révélation vient d'un rapport de l'expert du football africain Micky Junior, qui a mis en lumière l'impasse financière entre le joueur et son club.",
  ),
  Post(
    3,
    'asset/al.jpg',
    '10',
    '24/08/2023',
    'Transfert : Le TP Mazembe officialise Alioune Badara Faty',
    "Le TP Mazembe a accueilli ce samedi 22 juillet 2023 l’arrivée de Alioune Badara Faty. Le gardien de but sénégalais a rejoint les Corbeaux en provenance de Casa Sports du Sénégal. Alioune Badara Faty est recruté pour concurrencer Siadi Baggio au TP Mazembe. Il est arrivé samedi pour rejoindre l’effectif en pleine préparation. Le TP Mazembe se renforce en vue de participer à la Ligue Africaine de Football à partir d’octobre 2023. Alioune Badara Faty est un jeune espoir sénégalais. Il était de l’effectif des Lions de la Teranga vainqueur de la CAN 2021 et était aussi de la partie lors de la consécration du Sénégal au CHAN 2022. Chez les Corbeaux du TP Mazembe, il retrouvera son compatriote Jean Barthélémy Diouf, arrivé il y a quelques semaines",
  ),
  Post(
    4,
    'asset/m.webp',
    '9',
    '25/08/2023',
    "Mihayo a incendié ses joueurs et veut des renforts !",
    "Ce mercredi 14 décembre au Stade des Martyrs, les Corbeaux de TP Mazembe ont été battus (1-0) par l’AC Rangers en match comptant pour de la 9ème journée du championnat national de football (Vodacom Ligue 1) . Nouvelle désillusion pour Mihayo et ses hommes qui n’ont gagné en championnat depuis 3 matchs. Pamphile Mihayo tout simplement laissé éclater sa colère. Un langage fleuri directement adressé à certains joueurs de son groupe, accusés notamment de ne pas vouloir jouer, se donner à fond. « C’est un résultat humiliant pour nous. On ne peut pas continuer comme ça. On a tout fait, donné du renfort mental et psychologique mais au finish le message n’est pas passé. Je crois que l’équipe a besoin des renforts. Avec cet état d’esprit des différents joueurs sur le terrain (je sais pas citer les noms), tu vois que tu as des joueurs qui veulent pas jouer, qui ne se donnent pas à fond pour aller chercher à marquer des buts », a-t-il déclaré. Le TP Mazembe est en difficulté et s’éloigne un peu plus du podium et n’a pris qu’un point sur trois matchs joués sur le sol kinois, un nul (1-1) face à Renaissance, une défaite (2-1) contre Vita Club et 0-1 face à Rangers. Le club de Lubumbashi demeure 4ème au classement partiel avec 15 points en 9 rencontres. ",
  ),

  Post(
    6,
    'asset/mp.jpg',
    '9',
    '26/08/2023',

    "Le président de l'équipe Katumbi réalise des investissements majeurs dans le TP Mazembe"
,"Les travaux du nouveau stade du TP Mazembe ont été lancés ce jeudi 28 novembre en présence du président de la FIFA, Gianni Infantino et le Chairman Moïse Katumbi. Le Stade TP Mazembe ne répond plus à la demande de l’accueil des évènements dignes de la grandeur du Tout Puissant Mazembe Englebert. Le temple des Badiagwena, se révèle désormais insuffisant avec ses 18.000 places pour les milliers de fanatiques du club noir et blanc lorsqu’il s’agit des grandes rencontre de leur club en Linafoot ou en Ligue des Champions de la CAF.Le stade aura 50.000 places assises comme capacité d’accueil. Le président de la FIFA Gianni Infantino, celui de la CAF Hamad Hamad et celui de la FECOFA constan Omari ont été sur place pour visiter le site où sera construit ce bijou du football congolais. La pose symbolique de la première pierre a eu lieu à cette occasion. Le nouveau stade sera situé à l’entrée de la ville, sur la route Kasenga. L’emplacement du stade la route Kasenga, mettra en valeur le quartier Joli site surtout que c’est à côté de l’hôpital du cinquantenaire de Lubumbashi et au milieu des belles maisons nouvellement construit qui concourent à la beauté de la vill"
  ),
  Post(
    8,
    'asset/mpt.webp',
    '9',
    '28/08/2023',
    "le TP Mazembe condamne la légende du club pour violation des règles",
    "L'attaquant expérimenté a raté le vol de l'équipe pour Bukavu mercredi et le club va le punir pour sa dernière indiscrétion. Tout Puissant Mazembe s'est engagé à sanctionner la légende du club Tresor Mputu après son arrivée en retard sur le vol du club à destination de Bukavu mercredi.Le vol devait décoller à 7h00, heure locale, et les joueurs devraient arriver une heure plus tôt.Cependant, l'attaquant de la République démocratique du Congo est arrivé au moment où ils décollaient et a donc été abandonné à Lubumbashi.",
  ),
];
